using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Threading;
using System.Threading.Tasks;
using System;

public class carsLeft : MonoBehaviour
{
    public float speed = 3f;

    // Start is called before the first frame update
    void Start()
    {
        transform.position = new Vector2(19, 1.15f);
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(new Vector2(-2, 0) * speed * Time.deltaTime);
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Square")
        {
            Destroy(this.gameObject);
        }
    }
}
