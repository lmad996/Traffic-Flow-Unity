using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class lrSt : MonoBehaviour
{
    public GameObject[] carsRight;
    public GameObject[] carsLeft;
    public GameObject[] carsUp;
    public GameObject[] carsDown;
    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("GenerateCar", 1, 1);
    }
    // Update is called once per frame
    void Update()
    {

    }
    void GenerateCar()
    {
        Instantiate(carsRight[0], transform.position, Quaternion.identity);
        Instantiate(carsLeft[0], transform.position, Quaternion.identity);
    }
}
